﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Horista : Empregado //classe horista é herança (filha) de empregado
    {
        public double SalarioHora { get; set; } //propriedades
        public double NumeroHora { get; set; }
        public int DiasFalta { get; set; }

        public override int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);//pega o tempo trabalhado até o momento
            return (Convert.ToInt32(span.Days) - DiasFalta);//subtrai os dias que o empregado faltou
        }
        public override double SalarioBruto()//sobrescrevendo o método SalarioBruto, agora aplicado caso o empregado seja Horista
        {
            return SalarioHora * NumeroHora; //salario bruto do horista = numero de horas trabalhadas * valor da hora
        }


    }
}
