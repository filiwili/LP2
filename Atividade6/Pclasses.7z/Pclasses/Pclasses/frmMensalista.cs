﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }


        private void btnInstMens_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista();//criação do objeto mensalista
            ObjMensalista.NomeEmpregado = txtNome.Text; //setando o valor para as propriedades do projeto mensalista
            ObjMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            ObjMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrada.Text);
            ObjMensalista.SalarioMensal = Convert.ToDouble(txtSalarioMensal.Text);

            MessageBox.Show("Nome = "+ObjMensalista.NomeEmpregado + "\n" + "Matrícula = "+ObjMensalista.Matricula + "\n" + "Tempo Trabalho: "
                +ObjMensalista.TempoTrabalho()+" dias"+"\n"+"Salário Final: "+ObjMensalista.SalarioBruto().ToString("N2"));
        }

        private void btnInstMenParam_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text), txtNome.Text,
                Convert.ToDateTime(txtDataEntrada.Text),
                Convert.ToDouble(txtSalarioMensal.Text));
            MessageBox.Show("Nome = " + ObjMensalista.NomeEmpregado + "\n" + "Matrícula = " + ObjMensalista.Matricula + "\n" + "Tempo Trabalho: "
                + ObjMensalista.TempoTrabalho() + " dias" + "\n" + "Salário Final: " + ObjMensalista.SalarioBruto().ToString("N2"));


            //static
            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial);
        }
    }
}
