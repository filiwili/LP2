﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            
            InitializeComponent();
        }

        private void txtnum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum1.Text, out numero1))
            {
                MessageBox.Show("Número 1 Inválido!");
            
            }
        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresul.Text = resultado.ToString();
        }

        private void txtnum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresul.Text = resultado.ToString();
        }

        private void btnmul_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresul.Text = resultado.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("não pode dividir por zero!!!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtresul.Text = resultado.ToString();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Text = " ";
            txtnum2.Text = " ";
            txtresul.Text = " ";
            txtnum1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;
        }

        private void txtnum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum2.Text, out numero2))
            {
                MessageBox.Show("Número 2 Inválido!");
                txtnum2.Focus();
            }
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
