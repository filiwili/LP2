﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        private int [,] MVend;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string vend;
            int n = 2;
            double TotalMes = 0;
 
            MVend = new int[n, 4];

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    vend = Interaction.InputBox($"Digite o total de vendas do mês {i + 1} para a semana {j + 1}:", "Total de vendas", "").ToUpper();
                    if (!int.TryParse(vend, out MVend[i, j]))
                    {
                        MessageBox.Show("Insira um número válido.");
                    }
                    
                }
            }
            lstbxVendas.Items.Clear();

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                    lstbxVendas.Items.Add($"Total vendido no Mês {i + 1} da semana {j + 1}: {MVend[i, j]} ");
            }

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    TotalMes = TotalMes + MVend[i, j];
                }
                lstbxVendas.Items.Add($"Total vendido: {TotalMes} ");
            }
        }

        private void lbx_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.ClearSelected();
        }
    }
}
